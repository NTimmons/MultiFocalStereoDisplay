reset
make clean
make
echo Starting Application

../output/MultiFocalDisplayd

